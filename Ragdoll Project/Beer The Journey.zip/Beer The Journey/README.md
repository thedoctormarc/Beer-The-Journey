# Beer-The-Journey

### VERSION ###

1.0


### CONTROLS (voice input) ###

Move forward - "Adelante"
Turn right - "Right"
Turn left - "Left"
Stop - "Stop"
Kick - "Patada"


### WIN/LOSE ###

Get to the convenience store or die trying!
(Watch out for obstacles


### Authors ###

Gerard Clotet: https://github.com/GerardClotet 

Marc Doctor: https://github.com/thedoctormarc

Jorge Gemas: https://github.com/jorgegh2